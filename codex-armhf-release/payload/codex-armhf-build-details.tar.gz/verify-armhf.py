#!/usr/bin/env python3
"""Run inside the builder; tests genuine ARM ELF executables with QEMU user."""
import json
import os
from pathlib import Path
import queue
import subprocess
import tempfile
import threading
import time

root = Path('/work')
bins = Path(os.environ.get('CODEX_ARMHF_BIN_DIR', '/work/validated-binaries'))
logs = root / 'logs/validation'
logs.mkdir(parents=True, exist_ok=True)
server_only = os.environ.get('CODEX_ARMHF_VERIFY_SERVER_ONLY') == '1'
results_path = logs/('server-only-results.json' if server_only else 'results.json')
results_path.unlink(missing_ok=True)
runner = ['qemu-arm', '-cpu', 'cortex-a7', '-L', '/']
env = dict(os.environ, TOKIO_WORKER_THREADS='1', MALLOC_ARENA_MAX='2')
results = []

def run(label, cmd, expect=0):
    p = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=120)
    (logs / (label + '.txt')).write_text(p.stdout + '\nSTDERR:\n' + p.stderr)
    assert p.returncode == expect, (label, p.returncode, p.stderr[-3000:])
    results.append({'test': label, 'exit_code': p.returncode})
    return p.stdout

with tempfile.TemporaryDirectory(prefix='codex-armhf-tests-', dir=root) as tmp:
    env['CODEX_HOME'] = tmp
    for name in (['codex-app-server'] if server_only else ['codex', 'codex-app-server']):
        binary = bins / name
        assert binary.is_file(), binary
        run(name + '-file', ['file', str(binary)])
        header = run(name + '-elf-header', ['readelf', '-h', str(binary)])
        assert 'ELF32' in header and 'ARM' in header and 'hard-float ABI' in header
        run(name + '-elf-attributes', ['readelf', '-A', str(binary)])
        run(name + '-dynamic', ['readelf', '-d', '-V', str(binary)])
        run(name + '-loader', runner + ['/lib/ld-linux-armhf.so.3', '--list', str(binary)])
        version = run(name + '-version', runner + [str(binary), '--version'])
        assert '0.163.0' in version
        run(name + '-help', runner + [str(binary), '--help'])
    if not server_only:
        run('cli-features', runner + [str(bins/'codex'), 'features', 'list'])
    policy = Path(tmp) / 'probe.rules'
    policy.write_text('prefix_rule(pattern=["git", "status"], decision="allow")\n'
                      'prefix_rule(pattern=["rm"], decision="forbidden")\n')
    for command, decision in ([] if server_only else [(['git', 'status'], 'allow'), (['rm', '-rf', 'example'], 'forbidden')]):
        output = run('policy-' + decision, runner + [str(bins/'codex'), 'execpolicy', 'check', '--rules', str(policy), '--'] + command)
        assert json.loads(output)['decision'] == decision
    stderr = (logs/'app-server-rpc-stderr.txt').open('w')
    p = subprocess.Popen(runner + [str(bins/'codex-app-server'), '--listen', 'stdio://'], env=env,
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr,
                         text=True, bufsize=1)
    transcript = []
    messages = queue.Queue()
    def read_messages():
        try:
            for line in p.stdout:
                messages.put(json.loads(line))
        except Exception as error:
            messages.put(error)
        finally:
            messages.put(None)
    reader = threading.Thread(target=read_messages, daemon=True)
    reader.start()
    def send(value):
        transcript.append({'sent': value})
        p.stdin.write(json.dumps(value) + '\n')
        p.stdin.flush()
    def request(ident, method, params):
        send({'id': ident, 'method': method, 'params': params})
        deadline = time.monotonic() + 90
        while time.monotonic() < deadline:
            assert p.poll() is None, ('server exited', p.returncode)
            try:
                response = messages.get(timeout=1)
            except queue.Empty:
                continue
            assert isinstance(response, dict), ('server stdout closed or invalid', response)
            transcript.append({'received': response})
            if response.get('id') == ident:
                assert 'result' in response and 'error' not in response, response
                results.append({'test': 'rpc-' + method, 'result': 'passed'})
                return response['result']
        raise TimeoutError(method)
    try:
        request(1, 'initialize', {'clientInfo': {'name':'armhf_probe', 'version':'1.0.0'}})
        send({'method': 'initialized'})
        request(2, 'account/read', {'refreshToken': False})
        request(3, 'config/read', {'includeLayers': False})
        request(4, 'thread/list', {'limit': 5})
    finally:
        (logs/'app-server-rpc-transcript.json').write_text(json.dumps(transcript, indent=2) + '\n')
        try:
            p.stdin.close()
        except BrokenPipeError:
            pass
        try:
            p.wait(timeout=20)
        except subprocess.TimeoutExpired:
            p.terminate()
            p.wait(timeout=10)
        stderr.close()
        reader.join(timeout=5)
    assert p.returncode == 0, ('server shutdown', p.returncode)
results_path.write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps({'passed': True, 'tests': len(results)}))
