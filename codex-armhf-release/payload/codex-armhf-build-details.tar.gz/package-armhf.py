#!/usr/bin/env python3
"""Package only after actual ARMHF executable validation has passed."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

def normalize(info):
    info.uid = info.gid = 0
    info.uname = info.gname = 'root'
    return info

root = Path('/work')
source = root / 'codex'
bins = Path(os.environ.get('CODEX_ARMHF_BIN_DIR', '/work/validated-binaries'))
artifacts = root / 'artifacts'
results = json.loads((root/'logs/validation/results.json').read_text())
assert json.loads((root/'logs/validation/cli-mock-turn-passed.json').read_text())['passed'] is True
assert {'rpc-initialize', 'rpc-config/read', 'policy-allow', 'policy-forbidden'} <= {x['test'] for x in results}
stage = root / 'package-staging'
assert not stage.exists(), 'Use a fresh staging directory; do not overwrite an earlier package.'
(stage/'usr/bin').mkdir(parents=True)
doc = stage/'usr/share/doc/codex-armhf'
doc.mkdir(parents=True)
metadata = root/'package-metadata'
(metadata/'debian').mkdir(parents=True, exist_ok=True)
(metadata/'debian/control').write_text('Source: codex-armhf\nSection: devel\nPriority: optional\nMaintainer: Local ARMHF Build <root@localhost>\n\nPackage: codex-armhf\nArchitecture: armhf\nDescription: Experimental Codex ARMHF build\n')
for name in ['codex', 'codex-app-server']:
    binary = bins/name
    header = subprocess.check_output(['readelf', '-h', str(binary)], text=True)
    assert 'ELF32' in header and 'ARM' in header and 'hard-float ABI' in header
    shutil.copyfile(binary, stage/'usr/bin'/name)
    (stage/'usr/bin'/name).chmod(0o755)
command = ['dpkg-shlibdeps', '-O', '-l/usr/lib/arm-linux-gnueabihf'] + ['-e'+str(bins/n) for n in ['codex','codex-app-server']]
process = subprocess.run(command, cwd=metadata, text=True, capture_output=True,
                         env=dict(os.environ, DEB_HOST_ARCH='armhf', DEB_HOST_GNU_TYPE='arm-linux-gnueabihf'))
(root/'logs/dpkg-shlibdeps.txt').write_text(process.stdout+'\nSTDERR:\n'+process.stderr)
assert process.returncode == 0, process.stderr
dependency_line = next(line.removeprefix('shlibs:Depends=') for line in process.stdout.splitlines() if line.startswith('shlibs:Depends='))
assert 'libc6' in dependency_line and 'amd64' not in dependency_line and '-cross' not in dependency_line
dependencies = dependency_line + ', bubblewrap, ca-certificates'
readme = f'''# Codex 0.163.0: compilación experimental ARMHF

Contiene `codex` y `codex-app-server` compilados desde las fuentes oficiales:
https://github.com/openai/codex/tree/83086188ae0614bd882818ff1aa23f3194962012

Limitación funcional: esta entrega no incluye V8/Code Mode. Los modelos cuyo
catálogo indica `code_mode_only` (incluidos los gpt-6 de esta versión) requieren
un `codex-code-mode-host` compatible o remoto para sus herramientas; no basta
con desactivar esa función. La prueba de turno local usa metadatos de `gpt-5.5`,
que no exige ese modo. La disponibilidad de modelos en una cuenta real no se
ha comprobado. No es la distribución completa oficial de Codex.

Destino: `armv7-unknown-linux-gnueabihf`, ELF32 ARMv7 EABI5 hard-float,
little endian. Sistema previsto: Raspberry Pi OS de 32 bits, Debian Trixie.
Cargador: `/lib/ld-linux-armhf.so.3`. No son binarios ARM64 ni x86_64.
El sandbox requiere soporte del kernel para seccomp y namespaces, y permisos
para crear los namespaces necesarios. Estos requisitos dependen del kernel
y de la configuración de Raspberry Pi OS, además de las bibliotecas Debian.

Dependencias Debian calculadas mediante dpkg-shlibdeps:

    {dependencies}

Se recomienda disponer de `git`, `bash` y `ripgrep` para tareas de desarrollo.
Para usar el sandbox es obligatorio disponer de `bwrap` de la dependencia
`bubblewrap`: esta entrega no contiene el helper externo de la distribución
completa. Un mensaje de startup que anuncia un helper incorporado no demuestra
que ese helper exista junto a una compilación personalizada de dos binarios.
El archivo tar no contiene las bibliotecas del sistema; el paquete Debian
declara las dependencias anteriores para que APT las resuelva.

## Uso

Tras extraer el tar, ejecutar `./codex --version` o `./codex-app-server --help`.
Se pueden copiar ambos ejecutables a un directorio del PATH. Para el paquete:

    sudo apt install ./codex-armhf.deb

No se han ejecutado estas instrucciones ni instalado nada en una Raspberry.
El paquete no añade servicios ni inicia procesos automáticamente.
Codex necesita conexión a un proveedor y autenticación válida para inferencia.
La autenticación y las llamadas a modelos reales no se probaron en este trabajo.

## Cambios necesarios respecto a upstream

- Actualización de versiones internas del Cargo.lock de la etiqueta.
- `pagable 0.4.1`: comprobación del layout de 40 bytes específica de Linux ARM32.
- `codex-linux-sandbox`: conversiones de números de syscall de c_long a i64.
- `seccompiler 0.5.0`: arquitectura ARM32 y AUDIT_ARCH_ARM 0x40000028;
  tabla de syscalls ARM EABI para el frontend JSON opcional.

El informe, los parches y los registros del trabajo acompañan la entrega.
Es una compilación local experimental, sin soporte oficial de ARMHF.

## Pruebas y límites

Los dos ejecutables se han inspeccionado con file/readelf y ejecutado bajo
QEMU `-cpu cortex-a7`: versión, ayuda, reglas allow/forbidden y negociación
RPC de App Server (initialize, account/read, config/read, thread/list).
Las pruebas verifican ejecutables reales, no solamente cargo check.

El backend BPF pasó 14 pruebas ARMHF bajo QEMU. Instalar seccomp dentro de
QEMU de usuario devuelve ENOSYS: el aislamiento del kernel, bubblewrap,
namespaces y Landlock quedan pendientes de validación en hardware ARM.
No se ha desactivado el sandbox en el código para evitar estos límites.

No se incluyen los auxiliares `codex-code-mode-host` (V8), `codex-voice-host`
ni otros recursos de la distribución completa. Las funciones que los necesitan
no están disponibles en esta entrega de dos ejecutables. Para evitar intentar
usar el host local de code mode, se puede configurar en ~/.codex/config.toml:

    [features]
    code_mode = false
    code_mode_host = false

## Raspberry Pi de 512 MB

La compilación se hizo íntegramente en Codex Cloud. No hay mediciones en la Pi
ni garantía de que sesiones grandes, varias sesiones simultáneas o procesos
externos de desarrollo quepan en 512 MB. Ejecutar un solo proceso Codex,
limitar procesos externos y comenzar con:

    TOKIO_WORKER_THREADS=1 MALLOC_ARENA_MAX=2 ./codex

Para App Server se pueden usar las mismas variables. No hace falta ejecutar
CLI y App Server simultáneamente para utilizar cada uno por separado.
Los números de memoria medidos bajo QEMU incluyen el emulador.
'''
(doc/'README.md').write_text(readme)
for name in ['LICENSE', 'NOTICE']:
    if (source/name).exists():
        shutil.copyfile(source/name, doc/name)
for name in ['LICENSE-APACHE','LICENSE-BSD-3-Clause']:
    shutil.copyfile(source/'codex-rs/vendor/seccompiler-armhf'/name, doc/('seccompiler-'+name))
if (source/'codex-rs/vendor/bubblewrap/COPYING').exists():
    shutil.copyfile(source/'codex-rs/vendor/bubblewrap/COPYING', doc/'bubblewrap-COPYING')
(stage/'DEBIAN').mkdir()
size = sum(p.stat().st_size for p in (stage/'usr').rglob('*') if p.is_file())
(stage/'DEBIAN/control').write_text(f'''Package: codex-armhf
Version: 0.163.0+armhf1
Section: devel
Priority: optional
Architecture: armhf
Maintainer: Local ARMHF Build <root@localhost>
Installed-Size: {(size+1023)//1024}
Depends: {dependencies}
Recommends: git, bash, ripgrep
Homepage: https://github.com/openai/codex
Description: Experimental ARMHF build of Codex CLI and App Server
 Built from official Codex 0.163.0 sources with ARM32 compatibility patches.
 Tested under QEMU ARMv7; kernel sandbox and 512 MB hardware need validation.
 Does not include V8 code-mode or voice helper executables.
''')
for path in stage.rglob('*'):
    path.chmod(0o755 if path.is_dir() or path.parent == stage/'usr/bin' else 0o644)
(stage/'DEBIAN/md5sums').write_text(''.join(
    hashlib.md5(path.read_bytes()).hexdigest() + '  ' + str(path.relative_to(stage)) + '\n'
    for path in sorted((stage/'usr').rglob('*')) if path.is_file()))
subprocess.run(['dpkg-deb', '--root-owner-group', '-Zxz', '-z6', '--build', str(stage), str(artifacts/'codex-armhf.deb')], check=True)
with tarfile.open(artifacts/'codex-armhf.tar.gz', 'w:gz', compresslevel=6) as tar:
    for name in ['codex', 'codex-app-server']:
        tar.add(stage/'usr/bin'/name, arcname='codex-armhf/'+name, filter=lambda info: normalize(info))
    for path in doc.iterdir():
        tar.add(path, arcname='codex-armhf/'+path.name, filter=lambda info: normalize(info))
shutil.copyfile(doc/'README.md', artifacts/'README.md')
print(json.dumps({'dependencies':dependencies, 'installed_bytes':size}))
