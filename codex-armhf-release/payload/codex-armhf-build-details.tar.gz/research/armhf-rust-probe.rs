fn main() {
    println!("Rust ARMHF toolchain probe; pointers={} bits", usize::BITS);
    assert_eq!(usize::BITS, 32);
}
