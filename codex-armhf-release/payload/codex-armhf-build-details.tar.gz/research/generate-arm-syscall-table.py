#!/usr/bin/env python3
"""Generate seccompiler's optional JSON syscall map from ARM EABI headers."""
from pathlib import Path
import re

root = Path('/workspace/codex-armhf-work')
macros = (root / 'research/armhf-syscall-macros.txt').read_text()
assert '#define __NR_SYSCALL_BASE 0' in macros
calls = sorted((name, int(number)) for name, number in
               re.findall(r'^#define __NR_(\w+) \(__NR_SYSCALL_BASE \+ (\d+)\)$', macros, re.M))
assert dict(calls)['socket'] == 281
assert dict(calls)['io_uring_setup'] == 425
output = root / 'codex/codex-rs/vendor/seccompiler-armhf/src/syscall_table/arm.rs'
output.write_text('// Generated from Debian linux-libc-dev-armhf-cross 6.12.38-1cross1.\n'
                  '// ARM EABI only; __NR_SYSCALL_BASE = 0.\n'
                  'use std::collections::HashMap;\n\n'
                  'pub(crate) fn make_syscall_table() -> HashMap<&\'static str, i64> {\n'
                  '    vec![\n' + ''.join(f'        ("{name}", {number}),\n' for name, number in calls) +
                  '    ].into_iter().collect()\n}\n')
print('Generated', len(calls), 'ARM EABI syscall mappings')
