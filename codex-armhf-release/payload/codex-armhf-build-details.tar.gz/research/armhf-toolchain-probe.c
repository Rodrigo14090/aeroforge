#include <stdio.h>
#include <stdint.h>
int main(void) {
    printf("ARMHF toolchain probe; pointers=%zu bits; long=%zu bits\n", sizeof(void*) * 8, sizeof(long) * 8);
    return sizeof(void*) != 4;
}
