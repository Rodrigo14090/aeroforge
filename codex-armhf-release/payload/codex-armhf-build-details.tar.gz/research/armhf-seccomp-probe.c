#include <errno.h>
#include <linux/filter.h>
#include <linux/seccomp.h>
#include <stdio.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <unistd.h>
int main(void) {
    struct sock_filter instructions[] = { BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW) };
    struct sock_fprog program = { .len = 1, .filter = instructions };
    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0) {
        printf("PR_SET_NO_NEW_PRIVS failed: %s\n", strerror(errno));
        return 1;
    }
    if (syscall(SYS_seccomp, SECCOMP_SET_MODE_FILTER, 0, &program) != 0) {
        printf("ARMHF seccomp filter install failed: errno=%d (%s)\n", errno, strerror(errno));
        return errno == ENOSYS ? 77 : 1;
    }
    puts("ARMHF seccomp allow filter installed");
    return 0;
}
