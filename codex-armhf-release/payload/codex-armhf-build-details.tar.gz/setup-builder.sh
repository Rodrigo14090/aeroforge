#!/bin/bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
dpkg --add-architecture armhf
apt-get update
apt-get install -y --no-install-recommends ca-certificates curl git build-essential cmake ninja-build pkg-config clang lld g++-arm-linux-gnueabihf qemu-user file binutils dpkg-dev python3 time libssl-dev:armhf libcap-dev:armhf
curl -fsSL https://sh.rustup.rs -o /work/rustup-init.sh
sh /work/rustup-init.sh -y --no-modify-path --profile minimal --default-toolchain 1.95.0
export PATH="$CARGO_HOME/bin:$PATH"
rustup target add --toolchain 1.95.0 armv7-unknown-linux-gnueabihf
rustc +1.95.0 -vV
arm-linux-gnueabihf-gcc -v
qemu-arm --version
