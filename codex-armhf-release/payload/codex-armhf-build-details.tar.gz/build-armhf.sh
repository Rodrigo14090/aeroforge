#!/bin/bash
set -euo pipefail
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_TARGET_ARMV7_UNKNOWN_LINUX_GNUEABIHF_LINKER=arm-linux-gnueabihf-gcc
export CC_armv7_unknown_linux_gnueabihf=arm-linux-gnueabihf-gcc
export CXX_armv7_unknown_linux_gnueabihf=arm-linux-gnueabihf-g++
export AR_armv7_unknown_linux_gnueabihf=arm-linux-gnueabihf-ar
export PKG_CONFIG_ALLOW_CROSS=1
export PKG_CONFIG_LIBDIR=/usr/lib/arm-linux-gnueabihf/pkgconfig:/usr/share/pkgconfig
export OPENSSL_LIB_DIR=/usr/lib/arm-linux-gnueabihf
export OPENSSL_INCLUDE_DIR=/usr/include
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_RELEASE_DEBUG=0
export CARGO_PROFILE_RELEASE_STRIP=symbols
export CARGO_PROFILE_RELEASE_LTO=false
export CARGO_PROFILE_RELEASE_CODEGEN_UNITS=8
export CARGO_PROFILE_RELEASE_OPT_LEVEL=s
export CARGO_NET_GIT_FETCH_WITH_CLI=true
cd /work/codex/codex-rs
lock_args=(--locked)
if [[ "${CODEX_ARMHF_UPDATE_LOCK:-0}" == 1 ]]; then
    lock_args=()
fi
exec /usr/bin/time -v cargo +1.95.0 build "${lock_args[@]}" --release --target armv7-unknown-linux-gnueabihf -p codex-cli --bin codex -p codex-app-server --bin codex-app-server "$@"
