#!/usr/bin/env python3
import json
import os
from pathlib import Path
import signal

args = json.loads(Path('/work/logs/cli-link-original-argv.json').read_text())
output = args[args.index('-o')+1]
matches = []
for entry in Path('/proc').iterdir():
    if not entry.name.isdigit():
        continue
    try:
        command = [x.decode() for x in (entry/'cmdline').read_bytes().split(b'\0') if x]
    except (OSError, UnicodeDecodeError):
        continue
    if command and Path(command[0]).name in ['ld','ld.bfd','arm-linux-gnueabihf-ld'] and output in command:
        matches.append(int(entry.name))
assert len(matches) <= 1, matches
for pid in matches:
    os.kill(pid, signal.SIGTERM)
    print('Stopped only slow GNU CLI linker PID', pid, 'after successful LLD link and ARMv7 execution.')
if not matches:
    print('GNU linker had already finished; no process stopped.')
