#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('/work')
artifacts = root/'artifacts'
dest = root/'package-verification'
assert not dest.exists()
dest.mkdir()
def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
metadata = subprocess.check_output(['dpkg-deb','--field',str(artifacts/'codex-armhf.deb')],text=True)
assert 'Architecture: armhf\n' in metadata
assert 'Version: 0.163.0+armhf1\n' in metadata
(root/'logs/deb-control.txt').write_text(metadata)
contents = subprocess.check_output(['dpkg-deb','--contents',str(artifacts/'codex-armhf.deb')],text=True)
(root/'logs/deb-contents.txt').write_text(contents)
deb = dest/'deb'
subprocess.run(['dpkg-deb','--extract',str(artifacts/'codex-armhf.deb'),str(deb)],check=True)
tar = dest/'tar'
tar.mkdir()
with tarfile.open(artifacts/'codex-armhf.tar.gz') as archive:
    (root/'logs/tar-contents.txt').write_text('\n'.join(archive.getnames())+'\n')
    archive.extractall(tar,filter='data')
results = []
for label, folder in [('deb',deb/'usr/bin'),('tar',tar/'codex-armhf')]:
    for name in ['codex','codex-app-server']:
        binary = folder/name
        reference = root/'validated-binaries'/name
        assert digest(binary) == digest(reference), (label,name)
        description = subprocess.check_output(['file',str(binary)],text=True)
        assert 'ELF 32-bit' in description and 'ARM' in description and 'aarch64' not in description
        header = subprocess.check_output(['readelf','-h','-A',str(binary)],text=True)
        assert 'hard-float ABI' in header and 'Tag_CPU_arch: v7' in header
        version = subprocess.check_output(['qemu-arm','-cpu','cortex-a7','-L','/',str(binary),'--version'],text=True)
        assert '0.163.0' in version
        results.append({'archive':label,'name':name,'sha256':digest(binary),'file':description.strip(),'version':version.strip()})
(root/'logs/package-verification.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'passed':True,'verified_executables':len(results),'architecture':'armhf'}))
