#!/usr/bin/env python3
"""Retry just the live Cargo CLI link using the same Rust-produced objects."""
import json
from pathlib import Path
import subprocess

root = Path('/work')
candidates = []
for entry in Path('/proc').iterdir():
    if not entry.name.isdigit():
        continue
    try:
        args = [part.decode() for part in (entry/'cmdline').read_bytes().split(b'\0') if part]
    except (OSError, UnicodeDecodeError):
        continue
    if not args or Path(args[0]).name != 'arm-linux-gnueabihf-gcc' or '-o' not in args:
        continue
    output = args[args.index('-o')+1]
    if '/release/deps/codex-' in output:
        candidates.append(args)
assert len(candidates) == 1, len(candidates)
original = candidates[0]
(root/'logs/cli-link-original-argv.json').write_text(json.dumps(original,indent=2)+'\n')
command = original.copy()
command[command.index('-o')+1] = '/work/research/codex-cli-lld'
command = [arg for arg in command if not arg.startswith('-fuse-ld=')]
command.insert(1,'-fuse-ld=lld')
(root/'logs/cli-link-lld-argv.json').write_text(json.dumps(command,indent=2)+'\n')
result = subprocess.run(['/usr/bin/time','-v']+command)
raise SystemExit(result.returncode)
