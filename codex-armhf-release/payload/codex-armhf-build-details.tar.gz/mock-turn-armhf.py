#!/usr/bin/env python3
"""Exercise one CLI turn using a local HTTP mock, never a real model API."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import subprocess
import tempfile
import threading

root = Path('/work')
logs = root/'logs/validation'
logs.mkdir(parents=True, exist_ok=True)
(logs/'cli-mock-turn-passed.json').unlink(missing_ok=True)
calls = []
events = [
    {'type':'response.created', 'response':{'id':'armhf_mock_response'}},
    {'type':'response.output_item.done', 'item':{'type':'message', 'role':'assistant', 'id':'armhf_mock_message',
     'content':[{'type':'output_text', 'text':'ARMHF_EXECUTION_OK'}]}},
    {'type':'response.completed', 'response':{'id':'armhf_mock_response',
     'usage':{'input_tokens':1, 'input_tokens_details':None, 'output_tokens':1, 'output_tokens_details':None, 'total_tokens':2}}},
]
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass
    def do_POST(self):
        body = self.rfile.read(int(self.headers.get('Content-Length', '0')))
        calls.append({'path':self.path, 'body_bytes':len(body)})
        if not self.path.endswith('/responses'):
            self.send_error(404)
            return
        payload = ''.join('data: '+json.dumps(event)+'\n\n' for event in events).encode()
        self.send_response(200)
        self.send_header('Content-Type','text/event-stream')
        self.send_header('Content-Length',str(len(payload)))
        self.send_header('Connection','close')
        self.end_headers()
        self.wfile.write(payload)
        self.wfile.flush()
server = ThreadingHTTPServer(('127.0.0.1',0),Handler)
thread = threading.Thread(target=server.serve_forever,daemon=True)
thread.start()
try:
    with tempfile.TemporaryDirectory(prefix='codex-armhf-mock-',dir=root) as home:
        Path(home,'config.toml').write_text(f'''model = "gpt-5.5"
model_provider = "armhf_mock"
[model_providers.armhf_mock]
name = "Local ARMHF verification mock"
base_url = "http://127.0.0.1:{server.server_port}/v1"
wire_api = "responses"
requires_openai_auth = false
[features]
code_mode = false
code_mode_host = false
''')
        env = dict(os.environ,CODEX_HOME=home,TOKIO_WORKER_THREADS='1',MALLOC_ARENA_MAX='2')
        for name in ['NO_PROXY','no_proxy']:
            env[name] = env.get(name,'')+',127.0.0.1,localhost'
        command = ['/usr/bin/time','-v','qemu-arm','-cpu','cortex-a7','-L','/',
                   str(Path(os.environ.get('CODEX_ARMHF_BIN_DIR', '/work/validated-binaries'))/'codex'),
                   'exec','--ephemeral','--skip-git-repo-check','--json','Return the ARMHF test marker.']
        process = subprocess.run(command,env=env,text=True,capture_output=True,timeout=120)
        (logs/'cli-mock-turn-stdout.jsonl').write_text(process.stdout)
        (logs/'cli-mock-turn-stderr.txt').write_text(process.stderr)
        (logs/'cli-mock-turn-http.json').write_text(json.dumps(calls,indent=2)+'\n')
        assert process.returncode == 0, (process.returncode,process.stderr[-4000:])
        assert calls and 'ARMHF_EXECUTION_OK' in process.stdout, process.stdout
        records = [json.loads(line) for line in process.stdout.splitlines() if line.strip()]
        assert not any(record.get('item', {}).get('type') == 'error' for record in records), records
        assert any(record.get('type') == 'turn.completed' for record in records), records
        (logs/'cli-mock-turn-passed.json').write_text(json.dumps({'passed':True,'model':'gpt-5.5','mock_requests':len(calls)})+'\n')
        print('ARMv7 CLI completed a turn against a local mock; no real model API used.')
finally:
    server.shutdown()
    server.server_close()
