[CmdletBinding()]
param(
    [ValidateRange(1024,65535)][int]$Port = 46730,
    [string]$InstallDirectory = (Join-Path $env:LOCALAPPDATA 'CodexArmhf\hosts\0.163.0')
)
$ErrorActionPreference = 'Stop'
$binaryName = 'codex-code-mode-host-x86_64-pc-windows-msvc.exe'
$zipHash = 'bc82fa6d8f449c818292eac35bd7400c4f7dae08908fc9bc67bfbad8c4a3de68'
if (-not [Environment]::Is64BitOperatingSystem -or $env:PROCESSOR_ARCHITECTURE -notin @('AMD64','x86')) {
    throw 'This helper requires Windows x86-64; it is not an ARMHF or ARM64 binary.'
}
New-Item -ItemType Directory -Force -Path $InstallDirectory | Out-Null
$archive = Join-Path $InstallDirectory 'official-host.zip'
$binary = Join-Path $InstallDirectory $binaryName
if (-not (Test-Path -LiteralPath $archive)) {
    $temp = "$archive.download"
    $bundled = Join-Path $PSScriptRoot 'official-host.zip'
    if (Test-Path -LiteralPath $bundled) {
        Copy-Item -LiteralPath $bundled -Destination $temp
    } else {
        Invoke-WebRequest -UseBasicParsing -Uri "https://github.com/openai/codex/releases/download/rust-v0.163.0/$binaryName.zip" -OutFile $temp
    }
    if ((Get-FileHash -LiteralPath $temp -Algorithm SHA256).Hash.ToLowerInvariant() -ne $zipHash) {
        Remove-Item -LiteralPath $temp
        throw 'Official host ZIP checksum mismatch.'
    }
    Move-Item -LiteralPath $temp -Destination $archive
}
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $zipHash) {
    throw 'Cached ZIP checksum mismatch; restore the pinned official archive.'
}
# Re-extract from the verified archive so an altered cached EXE is never trusted.
Expand-Archive -LiteralPath $archive -DestinationPath $InstallDirectory -Force
Write-Host "Starting official Codex 0.163.0 V8 host on Windows loopback port $Port."
Write-Host 'Keep this terminal open. No ChatGPT token or API key is needed by this host.'
& $binary --listen "grpc://127.0.0.1:$Port"
exit $LASTEXITCODE
