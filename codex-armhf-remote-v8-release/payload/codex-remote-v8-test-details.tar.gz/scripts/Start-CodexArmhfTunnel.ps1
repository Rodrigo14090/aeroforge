[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidatePattern('^[A-Za-z0-9][A-Za-z0-9_.-]*$')][string]$SshHost,
    [ValidateRange(1024,65535)][int]$HostPort = 46730,
    [ValidateRange(1024,65535)][int]$ArmhfPort = 46731
)
$ErrorActionPreference = 'Stop'
Get-Command ssh.exe -ErrorAction Stop | Out-Null
Write-Host "Reverse tunnel: ${SshHost}:127.0.0.1:$ArmhfPort -> Windows:127.0.0.1:$HostPort"
Write-Host 'Use an existing trusted SSH-config alias. Keep this terminal open.'
Write-Host 'Host-key verification stays enabled; no password or key is stored by this script.'
# Native Win32 OpenSSH does not reliably support ControlMaster multiplexing.
# A separate tunnel avoids depending on private desktop connection internals.
& ssh.exe -N -T -o BatchMode=yes -o StrictHostKeyChecking=yes `
    -o ExitOnForwardFailure=yes -o ServerAliveInterval=30 -o ServerAliveCountMax=3 `
    -R "127.0.0.1:${ArmhfPort}:127.0.0.1:${HostPort}" $SshHost
exit $LASTEXITCODE
