#!/bin/bash
set -euo pipefail
root=/work/remote-code-mode/arm-root
mkdir -p "$root"/{usr/lib,bin,proc,dev,tmp,etc,work,root}
chmod 1777 "$root/tmp"
for deb in /work/remote-host-debs/*.deb; do dpkg-deb -x "$deb" "$root"; done
cp -a /usr/lib/arm-linux-gnueabihf "$root/usr/lib/"
ln -sfn usr/lib "$root/lib"
ln -sfn arm-linux-gnueabihf/ld-linux-armhf.so.3 "$root/usr/lib/ld-linux-armhf.so.3"
for name in sh cat uname id mkdir rm ls sleep head env wc true false dirname readlink; do ln -sfn /usr/bin/busybox "$root/bin/$name"; done
ln -sfn /usr/bin/bash "$root/bin/bash"
printf 'root:x:0:0:root:/root:/bin/bash\n' > "$root/etc/passwd"
printf 'root:x:0:\n' > "$root/etc/group"
cp /etc/resolv.conf "$root/etc/resolv.conf"
export PROOT_NO_SECCOMP=1
exec /work/remote-code-mode/proot-source/src/proot -q '/usr/bin/qemu-arm -cpu cortex-a7' -r "$root" -b /work -b /dev -b /proc -w /work /bin/bash --noprofile --norc -c 'printf "Bash=%s\n" "$BASH_VERSION"; /work/remote-code-mode/arm-proof; /usr/bin/busybox uname -m; /work/validated-binaries/codex-app-server --version'
