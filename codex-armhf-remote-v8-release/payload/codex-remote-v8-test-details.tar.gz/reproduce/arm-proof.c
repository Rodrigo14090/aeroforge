#include <stdio.h>
#include <unistd.h>
int main(void) {
#if !defined(__arm__) || !defined(__ARM_PCS_VFP)
#error ARM hard-float compilation required
#endif
    printf("ARMHF_NATIVE_TOOL pointer_bits=%zu pid=%ld hard_float=1\n", sizeof(void*)*8, (long)getpid());
    return sizeof(void*) == 4 ? 0 : 1;
}
