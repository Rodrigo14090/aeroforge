#!/usr/bin/env python3
"""Real ARMHF App Server, real external x86-64 V8, deterministic mock model.

Run only in the isolated Docker test container with --network=none. External
sandbox describes that container; it is never added to production launchers.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import queue
import re
import shlex
import subprocess
import sys
import threading
import time

ROOT=Path('/work/remote-code-mode')
LABEL=os.environ.get('TEST_LABEL','direct')
LOG=ROOT/'logs'/LABEL
LOG.mkdir(parents=True,exist_ok=True)
requests=[]
transcript=[]
pending=queue.Queue()
stop=threading.Event()
samples=[]
models=os.environ.get('TEST_MODELS','gpt-6.1-sol,gpt-6-astra,gpt-6-sol').split(',')
failure_test=os.environ.get('TEST_HOST_FAIL')=='1'

def event(kind, **kw): return {'type':kind,**kw}
def completed(ident):
    return event('response.completed',response={'id':ident,'usage':{'input_tokens':1,'output_tokens':1,'total_tokens':2,'input_tokens_details':None,'output_tokens_details':None}})

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def do_POST(self):
        try:
            raw=self.rfile.read(int(self.headers.get('Content-Length','0')))
            if self.headers.get('Content-Encoding')=='zstd':
                raw=subprocess.run(['zstd','-d','-q'],input=raw,capture_output=True,check=True).stdout
            body=json.loads(raw)
            requests.append(body)
            idx=len(requests)-1
            tag=f'turn{idx//2}'
            if idx%2==0:
                command=f"/work/remote-code-mode/arm-proof; printf 'BASH=%s\\n' \"$BASH_VERSION\"; uname -m; mkdir -p /evidence; printf '{tag}_ARMHF_FILE\\n' > /evidence/{tag}.txt"
                js='text({v8_js:true, bigint:String(2n**80n), node_process:typeof process, node_require:typeof require});\n'
                js+='const written=await tools.exec_command('+json.dumps({'cmd':command,'login':False,'max_output_tokens':500,'yield_time_ms':1000})+'); text(written);\n'
                js+='const read=await tools.exec_command('+json.dumps({'cmd':f'cat /evidence/{tag}.txt','login':False,'max_output_tokens':500})+'); text(read);'
                events=[event('response.created',response={'id':f'r{idx}'}),event('response.output_item.done',item={'type':'custom_tool_call','call_id':f'cm_{tag}','name':'exec','input':js}),completed(f'r{idx}')]
            else:
                events=[event('response.created',response={'id':f'r{idx}'}),event('response.output_item.done',item={'type':'message','id':f'm{idx}','role':'assistant','content':[{'type':'output_text','text':'TOOL_FLOW_COMPLETE'}]}),completed(f'r{idx}')]
            payload=''.join('data: '+json.dumps(e)+'\n\n' for e in events).encode()
            self.send_response(200)
            self.send_header('Content-Type','text/event-stream')
            self.send_header('Content-Length',str(len(payload)))
            self.send_header('Connection','close')
            self.end_headers()
            self.wfile.write(payload)
        except Exception as e:
            (LOG/'mock-error.txt').write_text(repr(e))
            self.send_error(500)

server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
hosterr=(LOG/'host-stderr.log').open('w')
host=subprocess.Popen([str(ROOT/'hosts/codex-code-mode-host-x86_64-unknown-linux-musl'),'--listen','grpc://127.0.0.1:0'],stdout=subprocess.PIPE,stderr=hosterr,text=True)
endpoint=host.stdout.readline().strip()
assert endpoint.startswith('http://127.0.0.1:'),endpoint
ssh_fixture=None
ssh_command=None
if os.environ.get('TEST_SSH')=='1':
    sys.path.insert(0,str(ROOT))
    import importlib.util
    spec=importlib.util.spec_from_file_location('ssh_fixture',ROOT/'ssh-test.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    ssh_fixture=module.tunnel(endpoint,LOG)
    endpoint,ssh_command=ssh_fixture.__enter__()
home=ROOT/'arm-root'/f'codex-home-{LABEL}'
home.mkdir(exist_ok=True)
(home/'config.toml').write_text(f'''model = "gpt-6.1-sol"
model_provider = "local_mock"
[model_providers.local_mock]
name = "Deterministic local test provider - no account or real model"
base_url = "http://127.0.0.1:{server.server_port}/v1"
wire_api = "responses"
requires_openai_auth = false
[features]
code_mode = true
code_mode_host = true
code_mode_prewarm = false
''')
env=dict(os.environ,CODEX_HOME='/'+home.name,PROOT_NO_SECCOMP='1',SHELL='/bin/bash',PATH='/bin:/usr/bin',RUST_LOG='codex_code_mode=info,codex_core::tools=info')
if os.environ.get('TEST_OPTIMIZED','1')=='1':
    env.update(TOKIO_WORKER_THREADS='1',MALLOC_ARENA_MAX='2')
env['NO_PROXY']=env['no_proxy']='127.0.0.1,localhost'
cmd=['/usr/bin/time','-v','-o',str(LOG/'app-server-time.txt'),str(ROOT/'proot-source/src/proot'),'-q','/usr/bin/qemu-arm -cpu cortex-a7','-r',str(ROOT/'arm-root'),'-b','/work','-b','/proc','-b','/dev','-b','/run/cloud-ca-bundle.pem','-w','/evidence','/work/validated-binaries/codex-app-server','--listen','stdio://','--code-mode-host',endpoint]
if os.environ.get('TEST_LAUNCHER'):
    cmd=cmd[:-5]+[os.environ['TEST_LAUNCHER'],'--listen','stdio://']
    env['CODEX_ARMHF_CODE_MODE_HOST']=endpoint
(ROOT/'arm-root/evidence').mkdir(exist_ok=True)
stderr=(LOG/'app-server-stderr.log').open('w')
if ssh_command:
    selected=('CODEX_HOME','PROOT_NO_SECCOMP','SHELL','PATH','RUST_LOG','TOKIO_WORKER_THREADS','MALLOC_ARENA_MAX','NO_PROXY','no_proxy','SSL_CERT_FILE','CODEX_ARMHF_CODE_MODE_HOST')
    remote_env=[f'{k}={env[k]}' for k in selected if k in env]
    cmd=ssh_command+[shlex.join(['env',*remote_env,*cmd])]
p=subprocess.Popen(cmd,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,text=True,bufsize=1)

def reader():
    for line in p.stdout:
        try: pending.put(json.loads(line))
        except Exception: pending.put({'invalid_line':line})
    pending.put(None)
threading.Thread(target=reader,daemon=True).start()
def sample():
    while not stop.wait(.05):
        row={'seconds':time.monotonic(),'host_pid':host.pid}
        for name,pid in [('host',host.pid)]:
            try:
                lines=Path(f'/proc/{pid}/status').read_text().splitlines()
                row[name]={x.split(':')[0]:x.split(':')[1].strip() for x in lines if x.startswith(('VmRSS:','VmHWM:','Threads:'))}
            except FileNotFoundError: pass
        row['armhf_processes']=[]
        for proc in Path('/proc').glob('[0-9]*'):
            try:
                if 'qemu-arm' not in os.readlink(proc/'exe'):continue
                args=(proc/'cmdline').read_bytes()
                if b'/validated-binaries/codex-app-server' not in args:continue
                lines=(proc/'status').read_text().splitlines()
                row['armhf_processes'].append({'pid':int(proc.name),**{x.split(':')[0]:x.split(':')[1].strip() for x in lines if x.startswith(('VmRSS:','VmHWM:','Threads:'))}})
            except (FileNotFoundError,PermissionError,ProcessLookupError):pass
        for f in ('memory.current','memory.peak','memory.events'):
            path=Path('/sys/fs/cgroup')/f
            if path.exists(): row[f]=path.read_text().strip()
        samples.append(row)
threading.Thread(target=sample,daemon=True).start()
def send(x):
    transcript.append({'send':x})
    p.stdin.write(json.dumps(x)+'\n'); p.stdin.flush()
def receive(deadline):
    x=pending.get(timeout=max(.1,deadline-time.monotonic()))
    assert isinstance(x,dict),('closed stream',p.poll())
    transcript.append({'recv':x})
    if 'method' in x and 'id' in x:
        raise AssertionError(('unexpected approval/client request',x))
    return x
def request(ident,method,params):
    send({'id':ident,'method':method,'params':params})
    deadline=time.monotonic()+150
    while True:
        x=receive(deadline)
        if x.get('id')==ident:
            assert 'result' in x,x
            return x['result']
result={'passed':False,'model_provider':'local deterministic mock, no real inference','v8_host':{'pid':host.pid,'elf':'x86-64','endpoint':endpoint},'ssh_multiplexed_appserver_and_reverse_forward':bool(ssh_command),'models':models,'optimized':os.environ.get('TEST_OPTIMIZED','1')=='1'}
try:
    request(1,'initialize',{'clientInfo':{'name':'armhf_remote_v8_test','version':'1'},'capabilities':{'experimentalApi':True}})
    send({'method':'initialized'})
    result['account']=request(2,'account/read',{'refreshToken':False})
    if failure_test:
        host.terminate();host.wait(timeout=10)
        for i in range(len(models)):
            (ROOT/f'arm-root/evidence/turn{i}.txt').unlink(missing_ok=True)
    for i,model in enumerate(models):
        thread=request(10+i*10,'thread/start',{'model':model,'cwd':'/evidence','ephemeral':True,'approvalPolicy':'on-request'})
        tid=thread['thread']['id']
        request(11+i*10,'turn/start',{'threadId':tid,'input':[{'type':'text','text':'Execute the deterministic Code Mode tool proof.'}],'sandboxPolicy':{'type':'externalSandbox','networkAccess':'enabled'}})
        deadline=time.monotonic()+150
        while True:
            x=receive(deadline)
            if x.get('method')=='turn/completed' and x.get('params',{}).get('threadId')==tid:
                assert x['params']['turn']['status']=='completed',x
                break
        assert len(requests)==(i+1)*2, len(requests)
        assert requests[-1]['model']==model
        outputs=[x for x in requests[-1].get('input',[]) if x.get('type')=='custom_tool_call_output']
        assert outputs,requests[-1].keys()
        if failure_test:
            failed_output=json.dumps(outputs)
            assert 'gRPC code-mode' in failed_output and 'failed' in failed_output,outputs
            assert 'ARMHF_NATIVE_TOOL pointer_bits=32' not in failed_output
            assert not (ROOT/f'arm-root/evidence/turn{i}.txt').exists()
            continue
        output=json.dumps(requests[-1].get('input'))
        for expected in ('ARMHF_NATIVE_TOOL pointer_bits=32','hard_float=1','BASH=5.2','armv7l',f'turn{i}_ARMHF_FILE','1208925819614629174706176'):
            assert expected in output,(expected,[x for x in requests[-1].get('input',[]) if x.get('type')=='custom_tool_call_output'])
        assert (ROOT/f'arm-root/evidence/turn{i}.txt').read_text()==f'turn{i}_ARMHF_FILE\n'
        assert not Path(f'/evidence/turn{i}.txt').exists()
    assert not any(x.get('recv',{}).get('method')=='error' for x in transcript), 'RPC error notification'
    result['passed']=True
    result['real_tool_calls']=0 if failure_test else len(models)*2
    result['external_host_failure_stops_tool_execution']=failure_test
finally:
    p.stdin.close()
    try:p.wait(timeout=30)
    except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=10)
    host.terminate();host.wait(timeout=10)
    stop.set()
    if ssh_fixture:ssh_fixture.__exit__(None,None,None)
    server.shutdown()
    stderr.close();hosterr.close()
    result['app_server_exit']=p.returncode
    timing=(LOG/'app-server-time.txt').read_text()
    result['armhf_appserver_peak_rss_kib']=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',timing).group(1))
    result['armhf_rss_measurement']='GNU time wait4 maximum RSS for App Server + QEMU/PRoot process tree, excludes external V8'
    result['x86_v8_host_peak_rss_kib']=max((int(row['host']['VmHWM'].split()[0]) for row in samples if 'host' in row),default=0)
    result['container_memory_peak_bytes']=max((int(row['memory.peak']) for row in samples if 'memory.peak' in row),default=0)
    result['memory_events_last']=samples[-1].get('memory.events') if samples else None
    (LOG/'rpc-transcript.json').write_text(json.dumps(transcript,indent=2)+'\n')
    (LOG/'model-requests.json').write_text(json.dumps(requests,indent=2)+'\n')
    (LOG/'tool-evidence.json').write_text(json.dumps([{'model':r.get('model'),'outputs':[x for x in r.get('input',[]) if x.get('type')=='custom_tool_call_output']} for r in requests if any(x.get('type')=='custom_tool_call_output' for x in r.get('input',[]))],indent=2)+'\n')
    (LOG/'memory-samples.json').write_text(json.dumps(samples,indent=2)+'\n')
    (LOG/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
