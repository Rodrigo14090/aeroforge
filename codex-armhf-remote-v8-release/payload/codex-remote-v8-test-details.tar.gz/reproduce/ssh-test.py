"""Loopback-only SSH fixture; throwaway keys never enter artifacts."""
from contextlib import contextmanager
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import time

def free_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1',0))
        return s.getsockname()[1]

@contextmanager
def tunnel(host_endpoint, log):
    with tempfile.TemporaryDirectory(prefix='codex-armhf-ssh-',dir='/run') as temp:
        root=Path(temp)
        for name in ('server','client'):
            subprocess.run(['ssh-keygen','-q','-t','ed25519','-N','','-f',str(root/name)],check=True)
        sshport=free_port(); forwardport=free_port()
        Path('/run/sshd').mkdir(exist_ok=True)
        config=root/'sshd_config'
        config.write_text(f'''Port {sshport}
ListenAddress 127.0.0.1
HostKey {root}/server
PidFile {root}/sshd.pid
AuthorizedKeysFile {root}/client.pub
PasswordAuthentication no
KbdInteractiveAuthentication no
PermitRootLogin prohibit-password
UsePAM no
StrictModes yes
AllowTcpForwarding remote
GatewayPorts no
PermitListen 127.0.0.1:{forwardport}
PermitOpen 127.0.0.1:{host_endpoint.rsplit(':',1)[1]}
PrintMotd no
LogLevel VERBOSE
''')
        pub=(root/'server.pub').read_text().split()
        (root/'known_hosts').write_text(f'[127.0.0.1]:{sshport} {pub[0]} {pub[1]}\n')
        sshlog=(log/'ssh-stderr.log').open('w')
        daemon=subprocess.Popen(['/usr/sbin/sshd','-D','-e','-f',str(config)],stderr=sshlog)
        master=None
        common=['ssh','-F','/dev/null','-p',str(sshport),'-i',str(root/'client'),'-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o',f'UserKnownHostsFile={root}/known_hosts','-o','ExitOnForwardFailure=yes','-S',str(root/'control')]
        try:
            for _ in range(100):
                try:
                    with socket.create_connection(('127.0.0.1',sshport),timeout=.2):break
                except OSError:time.sleep(.05)
            hostport=host_endpoint.rsplit(':',1)[1]
            master=subprocess.Popen(common+['-M','-N','-T','-R',f'127.0.0.1:{forwardport}:127.0.0.1:{hostport}','root@127.0.0.1'],stderr=sshlog)
            for _ in range(100):
                if (root/'control').exists():break
                assert master.poll() is None,'SSH master failed'
                time.sleep(.05)
            check=subprocess.run(common+['-O','check','root@127.0.0.1'],capture_output=True,text=True,check=True)
            (log/'ssh-master-check.txt').write_text(check.stderr)
            yield f'http://127.0.0.1:{forwardport}',common+['-T','root@127.0.0.1']
        finally:
            if master is not None:
                master.terminate(); master.wait(timeout=10)
            daemon.terminate();daemon.wait(timeout=10)
            sshlog.close()
