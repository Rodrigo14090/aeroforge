#!/usr/bin/env python3
"""Add post-extraction evidence after final archive execution succeeds."""
import importlib.util
import json
from pathlib import Path
import shutil

root=Path(__file__).resolve().parent
art=root/'artifacts'
spec=importlib.util.spec_from_file_location('packager',root/'package-remote-v8.py')
packager=importlib.util.module_from_spec(spec);spec.loader.exec_module(packager)
manifest=json.loads((art/'BUILD-MANIFEST.json').read_text())
verification=json.loads((root/'logs/package-verification.json').read_text())
assert verification['passed']
manifest['archive_verification']=verification
for label in ('archive-tar','archive-deb'):
    result=json.loads((root/'logs'/label/'result.json').read_text())
    assert result['passed'] and result['real_tool_calls']==4 and result['app_server_exit']==0
    manifest['tests'][label]=result
manifest['powershell_validation']=json.loads((root/'logs/powershell-syntax.json').read_text())
assert manifest['powershell_validation']['syntax_passed']
(art/'BUILD-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copyfile(root/'logs/package-verification.json',art/'PACKAGE-VERIFICATION.json')
entries=[]
for label in manifest['tests']:
    for name in ('result.json','tool-evidence.json','app-server-time.txt','ssh-master-check.txt','ssh-stderr.log'):
        p=root/'logs'/label/name
        if p.exists():entries.append((p,f'logs/{label}/{name}'))
for name in ('package-verification.json','package-verification-details.json','powershell-syntax.json'):
    entries.append((root/'logs'/name,'logs/'+name))
for name in ('test-flow.py','ssh-test.py','setup-arm-root.sh','arm-proof.c','package-remote-v8.py','finalize-delivery.py','verify-packages-remote.py','validate-powershell.ps1'):
    entries.append((root/name,'reproduce/'+name))
entries += [(p,'scripts/'+p.name) for p in sorted((root/'scripts').iterdir()) if p.is_file()]
packager.tgz(art/'codex-remote-v8-test-details.tar.gz',entries)
(art/'SHA256SUMS').write_text(''.join(f'{packager.digest(p)}  {p.name}\n' for p in sorted(art.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
for p in art.iterdir():
    if p.is_file():p.chmod(0o644)
print('Verified both final archives, attached evidence, and finalized checksums.')
