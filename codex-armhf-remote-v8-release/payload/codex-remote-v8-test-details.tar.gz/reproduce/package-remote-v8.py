#!/usr/bin/env python3
"""Stage/pack a new revision without changing any preserved executable."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
from zipfile import ZipFile,ZipInfo,ZIP_STORED,ZIP_DEFLATED

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
SOURCE=WORK/'codex'
STAGE=ROOT/'package-stage'
ART=ROOT/'artifacts'
EPOCH=1792454400
VERSION='0.163.0+armhf2.remotev8'
FILES=('codex','codex-app-server')
SCRIPTS=('codex-app-server-remote-v8','codex-remote-v8')
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def cp(src,dst,mode=0o644):
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(src,dst);dst.chmod(mode)
def tgz(target,entries):
    with target.open('wb') as f,gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=EPOCH,compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
        for src,name in sorted(entries,key=lambda x:x[1]):
            info=tar.gettarinfo(str(src),name)
            info.uid=info.gid=0;info.uname=info.gname='root';info.mtime=EPOCH
            info.mode=0o755 if info.isdir() or src.stat().st_mode & 0o111 else 0o644
            if info.isfile():
                with src.open('rb') as content:tar.addfile(info,content)
            else:tar.addfile(info)
def stage():
    assert not STAGE.exists(),'Staging directory already exists; do not overwrite prior results'
    for name in FILES:
        src=WORK/'validated-binaries'/name
        header=subprocess.check_output(['readelf','-h',str(src)],text=True)
        assert all(s in header for s in ('ELF32','ARM','hard-float ABI'))
        cp(src,STAGE/'usr/bin'/name,0o755)
    for name in SCRIPTS:cp(ROOT/'scripts'/name,STAGE/'usr/bin'/name,0o755)
    doc=STAGE/'usr/share/doc/codex-armhf'
    for name in ('README.md','INFORME-REMOTE-V8.md'):
        if (ROOT/name).exists():cp(ROOT/name,doc/name)
    for p in (ROOT/'scripts').glob('*'):
        if p.is_file() and p.name not in SCRIPTS:cp(p,doc/'remote-v8'/p.name)
    for name in ('LICENSE','NOTICE'):
        if (SOURCE/name).exists():cp(SOURCE/name,doc/name)
    for p in (WORK/'package-staging/usr/share/doc/codex-armhf').glob('*'):
        if p.is_file() and p.name not in ('README.md','LICENSE','NOTICE'):cp(p,doc/p.name)
    print(STAGE)
def pack():
    assert STAGE.exists()
    for label in ('ssh-optimized','ssh-baseline','packaged-launcher','host-unavailable'):
        r=json.loads((ROOT/'logs'/label/'result.json').read_text())
        assert r['passed'] and r['app_server_exit']==0,(label,r)
        assert r['external_host_failure_stops_tool_execution'] if label=='host-unavailable' else r['real_tool_calls']>=2
    for name in FILES:assert digest(STAGE/'usr/bin'/name)==digest(WORK/'validated-binaries'/name)
    ART.mkdir(exist_ok=False)
    doc=STAGE/'usr/share/doc/codex-armhf'
    for name in ('README.md','INFORME-REMOTE-V8.md'):cp(ROOT/name,doc/name)
    dependencies='libc6 (>= 2.39), libgcc-s1 (>= 4.3), libssl3t64 (>= 3.0.0), bubblewrap, ca-certificates, bash, coreutils'
    control=STAGE/'DEBIAN';control.mkdir()
    size=sum(p.stat().st_size for p in (STAGE/'usr').rglob('*') if p.is_file())
    (control/'control').write_text(f'''Package: codex-armhf
Version: {VERSION}
Section: devel
Priority: optional
Architecture: armhf
Maintainer: Experimental ARMHF Build <codex-armhf@localhost>
Installed-Size: {(size+1023)//1024}
Depends: {dependencies}
Recommends: git, ripgrep
Suggests: openssh-server
Homepage: https://github.com/openai/codex
Description: Experimental Codex ARMHF with external x86-64 V8 host support
 Preserves Codex 0.163.0 ARMv7 hard-float CLI and App Server binaries.
 Adds loopback-only remote Code Mode launchers, Windows SSH scripts and docs.
 Real ARMHF tool callbacks tested through external V8 and SSH under QEMU.
 Windows desktop integration and native ARM kernel sandbox remain unverified.
''')
    (control/'md5sums').write_text(''.join(f'{hashlib.md5(p.read_bytes()).hexdigest()}  {p.relative_to(STAGE)}\n' for p in sorted((STAGE/'usr').rglob('*')) if p.is_file()))
    STAGE.chmod(0o755)
    for p in STAGE.rglob('*'):
        p.chmod(0o755 if p.is_dir() or p.parent==STAGE/'usr/bin' else 0o644)
        os.utime(p,(EPOCH,EPOCH),follow_symlinks=False)
    subprocess.run(['dpkg-deb','--root-owner-group','-Zxz','-z6','--build',str(STAGE),str(ART/'codex-armhf.deb')],check=True,env=dict(os.environ,SOURCE_DATE_EPOCH=str(EPOCH)))
    entries=[(STAGE/'usr/bin'/n,n) for n in (*FILES,*SCRIPTS)]
    entries += [(p,str(Path('docs')/p.relative_to(doc))) for p in sorted(doc.rglob('*')) if p.is_file()]
    entries += [(ROOT/'README.md','README.md')]
    tgz(ART/'codex-armhf.tar.gz',entries)
    archive=ROOT/'hosts/windows-x86_64.zip'
    assert digest(archive)=='bc82fa6d8f449c818292eac35bd7400c4f7dae08908fc9bc67bfbad8c4a3de68'
    with ZipFile(ART/'codex-remote-v8-windows-x86_64.zip','w') as z:
        win=[(archive,'official-host.zip'),(ROOT/'README.md','README.md'),(SOURCE/'LICENSE','CODEX-LICENSE')]
        win += [(p,p.name) for p in sorted((ROOT/'scripts').glob('*.ps1'))]
        for src,name in win:
            info=ZipInfo(name,(2026,10,20,0,0,0));info.external_attr=0o644<<16
            z.writestr(info,src.read_bytes(),compress_type=ZIP_STORED if name.endswith('.zip') else ZIP_DEFLATED)
    linux=ROOT/'hosts/codex-code-mode-host-x86_64-unknown-linux-musl'
    assert digest(ROOT/'hosts/linux-x86_64.tar.gz')=='314263128ba6592e7e807c265deeaf928a692b72dcbfeb5e0b20c9423b703529'
    tgz(ART/'codex-remote-v8-linux-x86_64.tar.gz',[(linux,'codex-code-mode-host'),(ROOT/'README.md','README.md'),(SOURCE/'LICENSE','CODEX-LICENSE')])
    evidence=[]
    for label in ('ssh-optimized','ssh-baseline','packaged-launcher','host-unavailable'):
        for name in ('result.json','tool-evidence.json','app-server-time.txt','ssh-master-check.txt','ssh-stderr.log'):
            p=ROOT/'logs'/label/name
            if p.exists():evidence.append((p,f'logs/{label}/{name}'))
    for name in ('test-flow.py','ssh-test.py','setup-arm-root.sh','arm-proof.c','package-remote-v8.py','validate-powershell.ps1'):
        evidence.append((ROOT/name,'reproduce/'+name))
    evidence += [(p,'scripts/'+p.name) for p in sorted((ROOT/'scripts').iterdir()) if p.is_file()]
    tgz(ART/'codex-remote-v8-test-details.tar.gz',evidence)
    for name in ('README.md','INFORME-REMOTE-V8.md'):cp(ROOT/name,ART/name)
    cp(WORK/'artifacts/codex-armhf-source.patch',ART/'codex-armhf-source.patch')
    manifest={'version':VERSION,'upstream_tag':'rust-v0.163.0','upstream_commit':'83086188ae0614bd882818ff1aa23f3194962012','new_rust_source_changes':False,'armhf_binaries':{n:{'sha256':digest(STAGE/'usr/bin'/n),'bytes':(STAGE/'usr/bin'/n).stat().st_size,'unchanged_from_armhf1':True} for n in FILES},'host_sources':{'linux':{'sha256_archive':digest(ROOT/'hosts/linux-x86_64.tar.gz'),'binary_sha256':digest(linux),'target':'x86_64-unknown-linux-musl'},'windows':{'sha256_archive':digest(archive),'target':'x86_64-pc-windows-msvc','native_execution_tested':False}},'tests':{label:json.loads((ROOT/'logs'/label/'result.json').read_text()) for label in ('ssh-optimized','ssh-baseline','packaged-launcher','host-unavailable')},'real_chatgpt_plus_inference_tested':False,'official_windows_gui_tested':False}
    (ART/'BUILD-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (ART/'SHA256SUMS').write_text(''.join(f'{digest(p)}  {p.name}\n' for p in sorted(ART.iterdir()) if p.is_file()))
    print(json.dumps({p.name:{'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(ART.iterdir())},indent=2))
if __name__=='__main__':
    {'stage':stage,'pack':pack}[sys.argv[1]]()
