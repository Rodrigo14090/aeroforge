$ErrorActionPreference = 'Stop'
$validatedScripts = @()
foreach ($path in Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'scripts') -Filter '*.ps1') {
    $parseTokens = $null
    $parseErrors = $null
    [System.Management.Automation.Language.Parser]::ParseFile($path.FullName, [ref]$parseTokens, [ref]$parseErrors) | Out-Null
    if ($parseErrors.Count -gt 0) { throw ($parseErrors | Out-String) }
    Write-Output "Syntax OK: $($path.Name)"
    $validatedScripts += $path.Name
}
@{
    syntax_parser = "PowerShell $($PSVersionTable.PSVersion) Linux x86-64"
    scripts = $validatedScripts
    syntax_passed = $true
    windows_native_runtime_tested = $false
} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'logs/powershell-syntax.json') -Encoding utf8
