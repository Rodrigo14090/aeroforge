#!/usr/bin/env python3
"""Run inside the Cloud builder, with original ARMHF system libraries."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

ROOT=Path('/work/remote-code-mode')
ART=ROOT/'artifacts'
DEST=ROOT/'package-verification'
DEST.mkdir(exist_ok=False)
records=[]
def run(cmd,expect=0,env=None):
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=90,env=env)
    records.append({'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    assert p.returncode==expect,(cmd,p.returncode,p.stderr)
    return p.stdout
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
try:
    for line in (ART/'SHA256SUMS').read_text().splitlines():
        h,name=line.split('  ',1);assert sha(ART/name)==h,name
    with tarfile.open(ART/'codex-armhf.tar.gz') as t:t.extractall(DEST/'tar',filter='data')
    run(['dpkg-deb','-x',str(ART/'codex-armhf.deb'),str(DEST/'deb')])
    control=run(['dpkg-deb','-f',str(ART/'codex-armhf.deb')])
    assert 'Architecture: armhf' in control and 'Version: 0.163.0+armhf2.remotev8' in control
    assert 'bash' in control and 'coreutils' in control
    versions=[]
    for label,bins in [('tar',DEST/'tar'),('deb',DEST/'deb/usr/bin')]:
        for name in ('codex','codex-app-server'):
            binary=bins/name
            assert sha(binary)==sha(Path('/work/validated-binaries')/name)
            output=run(['file',str(binary)])
            assert 'ELF 32-bit' in output and 'ARM' in output and 'x86' not in output
            header=run(['readelf','-h',str(binary)])
            assert 'hard-float ABI' in header and 'ELF32' in header
            run(['readelf','-A','-d','-V',str(binary)])
            run(['qemu-arm','-cpu','cortex-a7','-L','/','/lib/ld-linux-armhf.so.3','--list',str(binary)])
            version=run(['qemu-arm','-cpu','cortex-a7','-L','/',str(binary),'--version'])
            assert '0.163.0' in version
            versions.append({'archive':label,'binary':name,'sha256':sha(binary),'version':version.strip()})
        # Check helpers in each format under the ARM root, including native ARM Bash.
        env=dict(os.environ,PROOT_NO_SECCOMP='1',CODEX_HOME='/work/remote-code-mode/package-verification/home')
        (DEST/'home').mkdir(exist_ok=True)
        runner=[str(ROOT/'proot-source/src/proot'),'-q','/usr/bin/qemu-arm -cpu cortex-a7','-r',str(ROOT/'arm-root'),'-b','/work','-b','/proc','-b','/dev','-w','/work']
        for args in [ ['--version'], ['app-server','--version'],['-c','features.code_mode_prewarm=false','app-server','--version'] ]:
            version=run(runner+[str(bins/'codex-remote-v8'),*args],env=env)
            assert '0.163.0' in version
        run(runner+[str(bins/'codex-remote-v8'),'app-server','daemon','start'],expect=64,env=env)
        for endpoint in ('http://0.0.0.0:46731','http://127.0.0.1:0','http://127.0.0.1:99999','http://127.0.0.1:bad','http://127.0.0.1:46731/path'):
            run(runner+[str(bins/'codex-app-server-remote-v8'),'--version'],expect=64,env=dict(env,CODEX_ARMHF_CODE_MODE_HOST=endpoint))
    for label in ('tar','deb'):
        for p in (DEST/label).rglob('*'):
            if not p.is_file():continue
            with p.open('rb') as f:head=f.read(20)
            if head.startswith(b'\x7fELF'):
                assert head[4]==1 and int.from_bytes(head[18:20],'little')==40, str(p)
    (ROOT/'logs/package-verification.json').write_text(json.dumps({'passed':True,'versions':versions,'checks':len(records)},indent=2)+'\n')
    print(json.dumps({'passed':True,'versions':versions,'checks':len(records)}))
finally:
    (ROOT/'logs/package-verification-details.json').write_text(json.dumps(records,indent=2)+'\n')
